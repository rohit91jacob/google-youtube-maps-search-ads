SYNTHETIC FIXTURE - made-up values in the real source's shape; not real data.
